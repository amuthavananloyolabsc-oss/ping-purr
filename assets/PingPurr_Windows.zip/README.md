# Ping & Purr

An animated desktop friend who lives on your screen, talks to you, and does all the
silly human things: bubble baths, brushing teeth, potty runs, laughing, sneezing,
dancing, exercising, sleeping, and real AI chat.

## Windows: use the standalone app (no Python needed)

1. Grab **PingPurr.exe** from the website (the quickest option).
2. Double-click it. Your companion walks onto the screen.

> First run may show "Windows protected your PC" — that is just Windows
> applying its "downloaded from the internet" mark to an unsigned app.
> Click **More info → Run anyway**, once. The app runs 100% on your machine.

### Smart App Control blocks it? Here is the toggle

Windows 11's **Smart App Control** is stricter than SmartScreen: it refuses to
run any app it has never seen before and offers no "run anyway" option, so it
will block this unsigned build. This is a system setting, not a problem with
the app. To allow Ping &amp; Purr:

1. Start → **Windows Security**
2. **App &amp; browser control** → **Smart App Control** → **Smart App Control settings**
3. Set it to **Off**.

> Smart App Control cannot be turned back on without resetting Windows, so
> only do this if you trust the file (this app runs 100% locally, nothing is
> uploaded). The only way to keep SAC on *and* run the app is a paid
> code-signing certificate — not possible for free builds.

## Or run from source (zip)

1. Install **Python 3.10+** from https://www.python.org/downloads/
   (on Windows tick *Add python to PATH*).
2. Unzip this package anywhere (e.g. your Desktop).
3. **Windows**: double-click `run_windows.bat`
   **Mac**: double-click `run_mac.command` (right-click → Open the first time).
4. Sign in with Google (a demo sign-in also works) → choose **Zara** or **Max** →
   your pet pops onto the screen, always-on-top.

### Windows blocked "run_windows.bat"? (normal for downloads)

Any file downloaded from the internet carries a "downloaded" mark, so Windows
blocks its `.bat` file. Fix it once:

1. **Unzip** the package to a folder (e.g. your Desktop).
2. Right-click `run_windows.bat` → **Properties** → **General** → tick **Unblock** → **OK**.
3. Run it again.

Or unblock everything from PowerShell:

```powershell
Unblock-File -Path "C:\path\to\your\unzipped\folder\*" -Recurse
```

> Tip: if you download with **Firefox**, the "Unblock" step is usually skipped.

1. Install **Python 3.10+** from https://www.python.org/downloads/
   (on Windows tick *Add python to PATH*).
2. Unzip this package anywhere (e.g. your Desktop).
3. **Windows**: double-click `run_windows.bat`
   **Mac**: double-click `run_mac.command` (right-click → Open the first time).
4. Sign in with Google (a demo sign-in also works) → choose **Zara** or **Max** →
   your pet pops onto the screen, always-on-top.

## Controls

| Interaction | What happens |
|---|---|
| Left-click your pet | Hug + happy hearts |
| Drag your pet | Move it anywhere on screen |
| Right-click your pet | Menu: Eat, Drink, Bath, Brush teeth, Toilet, Sleep, Wake up, Dance, Exercise, Laugh, Sneeze, **Chat with me**, Mute, Quit |
| Chat window | Your pet replies with its own personality (needs internet) |

Your pet gets hungry, bored, and sleepy. Keep it fed, played with, and rested.

## Google sign-in (production)

The app ships with a real Google OAuth flow. For production use, register a
[Google Cloud OAuth client](https://console.cloud.google.com/apis/credentials)
with **Redirect URI** `http://127.0.0.1:<port>/` (loopback), then launch with:

```bash
# Windows
set GOOGLE_CLIENT_ID=your_client_id.apps.googleusercontent.com
run_windows.bat

# Mac
GOOGLE_CLIENT_ID=your_client_id.apps.googleusercontent.com ./run_mac.command
```

Until then the app uses a friendly demo sign-in (identity stored locally).

## Files & data

- `pet_app.py` — the whole app (single file).
- `run_windows.bat` / `run_mac.command` — platform launchers.
- Profile (name, chosen character) is stored in
  `%APPDATA%\PingPurr\profile.json` (Windows) / `~/Library/Application Support`.

## Voices

- **Zara** uses a female voice (Windows: *Microsoft Zira*; Mac: *Samantha*).
- **Max** uses a male voice (Windows: *Microsoft David*; Mac: *Alex*).

## Troubleshooting

- *BAT closes instantly* → Python isn't installed or not on PATH.
- *No voice* → your OS may lack the listed SAPI voice; the pet still animates.
- *No internet* → chat falls back to scripted cute replies.
- *Mac 'cannot be opened'* → right-click → Open once to allow.